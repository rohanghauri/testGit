package seleniumApiTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "src/seleniumApiTesting/resources/drivers/chromedriver.exe");
		//Sets up the chrome driver to be used- The  driver and chrome version should be same
		captureRequests CaptureRequests = new captureRequests();
		//Makes an instance of the captureRequests class
		WebDriver driver = new ChromeDriver();
		//Makes a new instance of the webdriver named 'driver'
		CaptureRequests.captureHttp(driver, "chrome");
		//Calls the method captureHttp to record all the http requests
		driver.manage().window().maximize();
		//Maximizes the chrome window
		driver.get("https://www.cherrytechstore.com");
		//Launches the given url in the web browser
		driver.findElement(By.id("search")).sendKeys("Aukey");
		//Enters the word "Aukey" in the top search bar
		driver.findElement(By.id("search-param")).click();
		//Clicks the search button to search relevant products
		
		

	}

}
