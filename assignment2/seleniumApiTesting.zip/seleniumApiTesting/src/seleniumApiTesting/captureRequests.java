package seleniumApiTesting;

import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;

import org.openqa.selenium.devtools.v85.network.*;


public class captureRequests {
	DevTools devtools;
	public void captureHttp(WebDriver driver, String browserName) {
		
		if (browserName.equalsIgnoreCase("chrome")){
			devtools = ((ChromeDriver)driver).getDevTools();
		}
		devtools.createSession();
		devtools.send(Network.enable(Optional.empty(),Optional.empty(),Optional.empty()));
		devtools.addListener(Network.requestWillBeSent(), 
				entry->{
					System.out.println("Requested URL is: " + entry.getRequest().getUrl());
					System.out.println("Requested type is: " + entry.getRequest().getMethod());
				}
				);
		
	}
	

}
