//Auth M.Rohan Ghauri 231451151
package junitTesting;

public class calcMethods {

	public int isEven(int x) {
		if(x % 2 == 0) {
			return 1;
		}
		return 0;
	}
	 
	public int isOdd(int y) {
		if (y % 2 == 1) {
			return 1;
		}
		return 0;
	}
	
	public int mult(int a, int b) {
		return a*b;
	}
	
	//a should be greater than b
	public int sub(int a, int b){
		return a-b;
	}
	
	public int calcEq(int x, int y, int z) {
		//equation is (5x+y^2+9z)
		int t1 = 5*x;
		int t2 = y*y;
		int t3 = 9*z;
		return t1+t2+t3;
	}
	
}


