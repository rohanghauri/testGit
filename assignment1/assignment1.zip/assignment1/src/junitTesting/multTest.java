package junitTesting;

import static org.junit.Assert.*;

import org.junit.Test;

public class multTest {

	@Test
	public void test() {
		calcMethods mycalc = new calcMethods();
		int output = mycalc.mult(6,6);
		assertEquals(35,output);
	}

}
