package junitTesting;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class subTest {

	@Test
	public void test() {
		calcMethods mycalc = new calcMethods();
		int output = mycalc.sub(10,4);
		assertEquals(6,output);
	}

}
