package junitTesting;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class isEvenTest {

	@Test
	public void test() {
		calcMethods mycalc = new calcMethods();
		int output = mycalc.isEven(6);
		assertEquals(1,output);
	}

}
