package junitTesting;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class calcEqTest {

	@Test
	public void test() {
		calcMethods mycalc = new calcMethods();
		int output = mycalc.calcEq(1,1,1);
		assertEquals(11,output);
	}

}
