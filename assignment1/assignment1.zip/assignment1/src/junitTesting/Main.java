package junitTesting;

public class Main {

	public static void main(String[] args) {
		calcMethods mycalc = new calcMethods();
		int output1 = mycalc.isOdd(10);
		int output = mycalc.mult(10,4);
		int output2 = mycalc.sub(4,10);
		System.out.println(output2);	
	}
	
}
