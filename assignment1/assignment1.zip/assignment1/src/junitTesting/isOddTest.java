package junitTesting;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class isOddTest {

	@Test
	public void test() {
		calcMethods mycalc = new calcMethods();
		int output = mycalc.isOdd(5);
		assertEquals(1,output);
	}

}
