package junitTesting;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ isEvenTest.class, isOddTest.class, multTest.class, subTest.class,calcEqTest.class })
public class AllTests {

}
